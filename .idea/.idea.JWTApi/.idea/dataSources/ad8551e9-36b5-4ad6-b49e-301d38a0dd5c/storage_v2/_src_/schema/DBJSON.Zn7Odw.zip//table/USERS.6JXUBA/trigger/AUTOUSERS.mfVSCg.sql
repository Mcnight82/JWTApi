create trigger AUTOUSERS
    before insert
    on USERS
    for each row
BEGIN
        SELECT IDUSERS.NEXTVAL INTO :NEW.IDUSER FROM DUAL;
    END;
/

