create trigger AUTOIPERIODO
    before insert
    on IPERIODO
    for each row
BEGIN
        SELECT IDPERIODO.NEXTVAL INTO :NEW.IDPERIODO FROM DUAL;
    END;
/

